until unconvert -fastmath . &> /dev/null
do
	unconvert -fastmath -apply . &> /dev/null
done
