#define MAP_32BIT      0x40
