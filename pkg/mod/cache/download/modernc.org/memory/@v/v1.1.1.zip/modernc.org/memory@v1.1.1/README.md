# memory

Package memory implements a memory allocator.

## Build status

available at https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2fmemory

Installation

    $ go get modernc.org/memory

Documentation: [godoc.org/modernc.org/memory](http://godoc.org/modernc.org/memory)
